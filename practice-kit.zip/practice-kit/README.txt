Practice kit · AI that works workshop · all data is fake

receipts/      six receipts (PDF)            → task: Expenses
notes.txt      a meeting transcript          → task: Meeting notes
data.csv       8 weeks of product metrics    → task: Data to report
post.md        a short blog post             → task: Marketing
contract.pdf   a consulting agreement        → task: Contract or document

Unzip this whole folder into your `assistant` folder, then follow the guide.
