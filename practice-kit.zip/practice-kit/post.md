# Why walking meetings work

Most meetings don't need a table. They need two people, a problem, and twenty minutes. Walking meetings take that seriously.

When you walk side by side, conversation gets easier. You aren't staring at each other or at a screen, so people speak more freely and interrupt less. Research on walking and creativity has found people come up with more ideas while walking than while sitting.

There's a practical upside too. A walk has a natural length. You loop back to the office and the meeting is over, which beats the hour-long default that fills itself no matter what.

They aren't for everything. Anything that needs a screen, a document or more than three people still belongs indoors. But for one-on-ones, brainstorming and hard conversations, getting outside works surprisingly well.

Try it this week: pick one meeting, suggest a walk, and send a two-line summary afterwards so nothing gets lost.
